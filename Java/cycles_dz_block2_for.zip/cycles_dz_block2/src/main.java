public class main
{
    public static void main(String[] args)
    {
        System.out.println();
        System.out.print("Билет с номером: ");
        System.out.println();

        for (int tiket = 200000; tiket <= 210000; tiket = tiket + 1)
            System.out.print(tiket + ",");

        System.out.println();
        System.out.println();
        System.out.print("Билет с номером: ");
        System.out.println();

        for (int tiket = 220000; tiket <= 235000; tiket = tiket + 1)
            System.out.print(tiket + ",");
    }
}