public class main
{
    public static void main(String[] args)
    {
        System.out.println();
        System.out.print("Билет с номером: ");
        System.out.println();

        int tiket = 200000;
        while (tiket <= 210000) {
            System.out.println(tiket + ",");
            tiket++;
        }

        //======================================

        System.out.println();
        System.out.print("Билет с номером: ");
        System.out.println();

        int tiket2 = 220000;
        while (tiket2 <= 235000) {
            System.out.println(tiket2 + ",");
            tiket2++;
        }
    }
}