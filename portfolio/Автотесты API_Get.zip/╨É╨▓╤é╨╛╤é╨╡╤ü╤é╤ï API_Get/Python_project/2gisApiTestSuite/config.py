BASE_URL = "https://regions-test.2gis.com/1.0/regions"
